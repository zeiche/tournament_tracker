#!/usr/bin/env python3
"""
Clean TwiML server - ONLY the working endpoint with NO competing routes
"""

from flask import Flask, Response, request
import sys
import os

# Add path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

@app.route('/voice-stream.xml', methods=['GET', 'POST'])
def voice_stream():
    """Return TwiML with IVR intro then bidirectional Stream for real-time interaction."""
    
    # Get caller info if available
    from_number = request.values.get('From', 'Unknown')
    call_sid = request.values.get('CallSid', '')
    
    # Direct connect to WebSocket - NO "connecting" message
    twiml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Connect>
        <Stream url="ws://0-page.com:8087/">
            <Parameter name="caller" value="{from_number}"/>
            <Parameter name="mode" value="polymorphic_transcription"/>
        </Stream>
    </Connect>
</Response>'''
    
    return Response(twiml, mimetype='text/xml')

@app.route('/', methods=['GET'])
def index():
    """Status page."""
    return """
<h1>Clean TwiML Server</h1>
<p>Endpoint: /voice-stream.xml</p>
<p>WebSocket: ws://0-page.com:8087/</p>
<p>No competing routes. No "connecting" messages.</p>
"""

if __name__ == '__main__':
    print("🧹 Starting CLEAN TwiML server on port 8086")
    print("📞 Single endpoint: /voice-stream.xml")
    print("🔗 Direct connect - no announcements")
    app.run(host='0.0.0.0', port=8086, debug=False)