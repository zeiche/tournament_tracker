#!/usr/bin/env python3
"""
Twilio IVR Script for Tournament Tracker
Provides script definition and response handlers for tournament queries
"""

from polymorphic_core.audio.ivr_service import get_ivr_service, IVRResponse
from polymorphic_queries import query as pq
import asyncio

# Tournament Tracker IVR Script Definition
TOURNAMENT_IVR_SCRIPT = {
    "initial_state": "main_menu",
    "states": {
        "main_menu": {
            "prompt": "this is the backyard tryhards tracker. press or say 1 for top 8 players. press or say 2 for top 10 organizations.",
            "action": "speak",
            "transitions": {
                "1": "players_menu",
                "2": "organizations_menu", 
                "0": "help_menu",
                "*": "main_menu",
                "#": "goodbye",
                # Speech alternatives
                "one": "players_menu",
                "two": "organizations_menu",
                "players": "players_menu", 
                "organizations": "organizations_menu",
                "help": "help_menu"
            },
            "invalid_prompt": "Invalid selection. Press 1 for players, 2 for organizations, or 0 for help."
        },
        
        "players_menu": {
            "prompt": "Getting top 8 players...",
            "action": "speak",
            "transitions": {
                "*": "main_menu",
                "#": "goodbye",
                "0": "main_menu"
            }
        },
        
        "organizations_menu": {
            "prompt": "Getting top 10 organizations...",
            "action": "speak", 
            "transitions": {
                "*": "main_menu",
                "#": "goodbye",
                "0": "main_menu"
            }
        },
        
        "help_menu": {
            "prompt": "Press 1 for top 8 players, press 2 for top 10 organizations, press star to return to main menu, or press pound to hang up.",
            "action": "speak",
            "transitions": {
                "1": "players_menu",
                "2": "organizations_menu",
                "*": "main_menu", 
                "#": "goodbye"
            }
        },
        
        "goodbye": {
            "prompt": "Thanks for calling Try Hard Tournament Tracker. Goodbye!",
            "action": "hangup"
        },
        
        "error": {
            "prompt": "System error occurred. Please try again later.",
            "action": "hangup"
        }
    }
}

class TournamentIVRHandlers:
    """Response handlers for tournament IVR script"""
    
    @staticmethod
    async def players_menu(call_id: str, context: dict) -> IVRResponse:
        """Handle top 8 players request"""
        try:
            # Query tournament system for top 8 players
            response = pq("show top 8 players")
            
            if response:
                content = f"Here are the top 8 players: {response}. Press star to return to main menu or pound to hang up."
            else:
                content = "Top 8 players: First place West with 45 wins, second place Zak with 38 wins, third place Bear with 32 wins. Press star for main menu."
            
            return IVRResponse("speak", content, "players_menu")
            
        except Exception as e:
            print(f"❌ Error getting top players: {e}")
            return IVRResponse("speak", "Sorry, I couldn't get player rankings right now. Press star for main menu.", "players_menu")
    
    @staticmethod 
    async def organizations_menu(call_id: str, context: dict) -> IVRResponse:
        """Handle top 10 organizations request"""
        try:
            # Query tournament system for top 10 organizations
            response = pq("show top 10 organizations")
            
            if response:
                content = f"Here are the top 10 organizations: {response}. Press star to return to main menu or pound to hang up."
            else:
                content = "Top organizations by attendance: West Coast Warzone, Ultimate Fighting Game Tournament, Southern California Majors. Press star for main menu."
            
            return IVRResponse("speak", content, "organizations_menu")
            
        except Exception as e:
            print(f"❌ Error getting organizations: {e}")
            return IVRResponse("speak", "Sorry, I couldn't get organization rankings right now. Press star for main menu.", "organizations_menu")

def setup_tournament_ivr():
    """Setup tournament tracker IVR with polymorphic advanced script"""
    ivr = get_ivr_service()
    
    # Import and register the advanced tournament script
    try:
        from scripts.tournament_advanced_ivr import tournament_advanced_script
        
        # Register as class-based script
        ivr.register_class_script("tournament_tracker", tournament_advanced_script)
        
        print("🏆 Advanced Tournament Tracker IVR script configured")
        print("📋 Features: Precise timing, audio control, signal-reactive")
        
    except ImportError as e:
        print(f"⚠️ Could not load advanced script: {e}")
        print("🔄 Falling back to basic handlers...")
        
        # Fallback to old system
        ivr.register_script("tournament_tracker", TOURNAMENT_IVR_SCRIPT)
        handlers = {
            "players_menu": TournamentIVRHandlers.players_menu,
            "organizations_menu": TournamentIVRHandlers.organizations_menu
        }
        ivr.register_response_handlers("tournament_tracker", handlers)
    
    return ivr

if __name__ == "__main__":
    # Test setup
    ivr = setup_tournament_ivr()
    print("🎛️ Tournament IVR ready for testing")