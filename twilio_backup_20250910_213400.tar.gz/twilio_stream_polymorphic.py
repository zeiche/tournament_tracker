#!/usr/bin/env python3
"""
Twilio Stream handler with polymorphic transcription integration.
Connects Twilio media streams to the polymorphic transcription system.
"""

import asyncio
import websockets
import json
import base64
import struct
import ssl
import pathlib
from datetime import datetime
from typing import Optional, Dict, Any
import os
import sys

# Add parent dir to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import polymorphic components
try:
    from polymorphic_core import announcer, discover_capability
except ImportError:
    class DummyAnnouncer:
        def announce(self, *args, **kwargs):
            pass
    announcer = DummyAnnouncer()
    def discover_capability(name):
        return None

try:
    from polymorphic_queries import query as pq
except ImportError:
    def pq(query):
        return f"Tournament data query: {query}"

# Import the transcription bridge
try:
    from twilio_transcription_bridge import get_twilio_bridge
    twilio_bridge = get_twilio_bridge()
except ImportError:
    print("⚠️ Twilio transcription bridge not available")
    twilio_bridge = None

# Import the audio mixer
try:
    from experimental.audio.bonjour_audio_mixer import get_mixer
    audio_mixer = get_mixer()
except ImportError:
    print("⚠️ Bonjour audio mixer not available")
    audio_mixer = None

# 🚫 BLOCK DIRECT AUDIO PLAY() COMMANDS - USE MIXER ONLY! 🚫
def play(*args, **kwargs):
    """
    ❌ BLOCKED: Direct play() is FORBIDDEN! 
    
    🎚️ USE THE MIXER SYSTEM INSTEAD:
    - audio_mixer.mix_realtime(text) 
    - send_tts_response(websocket, text)
    - announcer.announce() for audio requests
    
    🚨 CLAUDE: You worked hard on the mixer - USE IT!
    """
    error_msg = """
    ❌❌❌ PLAY() COMMAND BLOCKED! ❌❌❌
    
    You tried to use play() but this bypasses the mixer system!
    
    🎚️ USE THESE INSTEAD:
    • audio_mixer.mix_realtime(text) - For mixed TTS + music
    • send_tts_response(websocket, text) - For WebSocket TTS  
    • announcer.announce() - For audio announcements
    
    🔄 The mixer handles all audio - don't circumvent it!
    """
    print(error_msg)
    raise RuntimeError("play() is BLOCKED - use mixer system instead!")

# Block pygame/playsound if imported
import builtins
original_import = builtins.__import__

def blocked_import(name, *args, **kwargs):
    if name in ['pygame', 'playsound', 'pydub.playback']:
        print(f"🚫 BLOCKED IMPORT: {name} - Use mixer system instead!")
        raise ImportError(f"Direct audio libraries blocked - use mixer system!")
    return original_import(name, *args, **kwargs)

builtins.__import__ = blocked_import

# Import the DTMF detector
try:
    from polymorphic_core.audio.dtmf_detector import get_dtmf_detector
    dtmf_detector = get_dtmf_detector()
except ImportError:
    print("⚠️ DTMF detector not available")
    dtmf_detector = None

# Import the TTS service
try:
    from polymorphic_core.audio.tts_service import _tts_service
    tts_service = _tts_service
    print("✅ TTS service imported and available")
except ImportError:
    print("⚠️ TTS service not available")
    tts_service = None

# Import the polymorphic IVR service
try:
    from polymorphic_core.audio.ivr_service import get_ivr_service
    from twilio_ivr_script import setup_tournament_ivr
    ivr_service = setup_tournament_ivr()
except ImportError:
    print("⚠️ Polymorphic IVR service not available")
    ivr_service = None

class TwilioStreamPolymorphic:
    """Handles Twilio streams with polymorphic transcription integration."""
    
    def __init__(self):
        self.call_sid = None
        self.stream_sid = None
        self.custom_params = {}
        self.audio_buffer = bytearray()
        self.transcription_service = None
        self.tts_service = None
        
        # Discover polymorphic services
        self.transcription_service = discover_capability('transcription')
        self.tts_service = discover_capability('tts')
        
        # Listen for transcription results
        self.transcription_results = {}
        
        # Announce ourselves
        announcer.announce(
            "Twilio Stream Polymorphic",
            [
                "I connect Twilio streams to polymorphic services",
                "I forward audio to polymorphic transcription",
                "I handle TTS responses via audio mixer",
                "I integrate with the Bonjour ecosystem",
                "I use AUDIO_AVAILABLE announcements",
                "I listen for TRANSCRIPTION_COMPLETE",
                "I listen for AUDIO_MIXED from the mixer"
            ]
        )
        
        # Register for transcription results
        self.register_for_announcements()
    
    def register_for_announcements(self):
        """Register to receive transcription and audio announcements"""
        # In a full implementation, this would register with the announcement system
        # For now, we'll poll or check directly
        announcer.announce(
            "TwilioStreamPolymorphic",
            [
                "Registered for TRANSCRIPTION_COMPLETE announcements",
                "Registered for AUDIO_MIXED announcements from mixer"
            ]
        )
    
    async def handle_websocket(self, websocket, path):
        """Handle incoming WebSocket connection from Twilio."""
        print(f"🔌 WebSocket connected from {websocket.remote_address}")
        
        try:
            async for message in websocket:
                if isinstance(message, str):
                    await self.process_message(websocket, message)
                else:
                    # Handle binary audio data
                    await self.process_binary_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            print("📴 WebSocket connection closed")
        except Exception as e:
            print(f"❌ WebSocket error: {e}")
    
    async def process_message(self, websocket, message: str):
        """Process incoming WebSocket messages from Twilio."""
        print(f"📨 Received WebSocket message: {message[:200]}...")
        try:
            data = json.loads(message)
            event = data.get('event')
            print(f"🎯 Processing event: {event}")
            
            if event == 'connected':
                print("✅ Twilio connected")
                print(f"Protocol: {data.get('protocol')}")
                # Don't send any response to connected event - Twilio doesn't expect one
                
            elif event == 'start':
                # Stream metadata
                start_data = data.get('start', {})
                self.call_sid = start_data.get('callSid')
                self.stream_sid = start_data.get('streamSid')
                self.custom_params = start_data.get('customParameters', {})
                self.current_websocket = websocket  # Store for TTS use
                
                print(f"📞 Call started: {self.call_sid}")
                print(f"🎙️ Stream: {self.stream_sid}")
                print(f"📝 Custom params: {self.custom_params}")
                
                # Register with transcription bridge
                if twilio_bridge:
                    twilio_bridge.register_twilio_handler(self.call_sid, websocket, self)
                    print(f"🌉 Registered with transcription bridge: {self.call_sid}")
                
                # Check if we should announce time via mixer
                print(f"🔍 Checking announce_time param: {self.custom_params.get('announce_time')}")
                if self.custom_params.get('announce_time') == 'true':
                    print("🕒 Announcing time via audio mixer...")
                    await self._announce_time_via_mixer(websocket)
                else:
                    print("ℹ️ No time announcement requested")
                
                # Connect audio mixer for music playback
                if audio_mixer:
                    print("🎚️ Connecting audio mixer with music playbook")
                    audio_mixer.start_continuous_music()
                    
                    # Stream mixer output directly to Twilio
                    asyncio.create_task(self.stream_mixer_to_twilio(websocket))
                    print("🎵 Background music streaming enabled")
                else:
                    print("⚠️ Audio mixer not available")
                
                # Start IVR session instead of hardcoded greeting
                if ivr_service:
                    await self.start_ivr_session(websocket)
                else:
                    # Fallback greeting if IVR not available
                    await self.send_tts_response(
                        websocket,
                        "this is the backyard tryhards tracker. press or say 1 for player rankings. 2 for organization attendnance rankings."
                    )
                
            elif event == 'media':
                # Incoming audio data
                media = data.get('media', {})
                audio_payload = media.get('payload')
                
                if audio_payload:
                    # Decode base64 audio
                    audio_bytes = base64.b64decode(audio_payload)
                    self.audio_buffer.extend(audio_bytes)
                    
                    # Process audio every ~2 seconds worth of data
                    if len(self.audio_buffer) >= 16000:  # 2 sec at 8kHz mulaw
                        await self.process_audio_buffer(websocket)
                
            elif event == 'stop':
                print(f"🛑 Stream stopped: {self.stream_sid}")
                
                # End IVR session
                if ivr_service and self.call_sid:
                    ivr_service.end_call(self.call_sid)
                    print(f"🎛️ IVR session ended: {self.call_sid}")
                
                # Stop mixer output stream
                if hasattr(self, 'mixer_task'):
                    self.mixer_task.cancel()
                    print("🎚️ Mixer output task cancelled")
                
                # Unregister from transcription bridge
                if twilio_bridge and self.call_sid:
                    twilio_bridge.unregister_twilio_handler(self.call_sid)
                    print(f"🌉 Unregistered from transcription bridge: {self.call_sid}")
                
            elif event == 'mark':
                # Custom mark event
                mark = data.get('mark', {})
                print(f"📍 Mark received: {mark.get('name')}")
                
        except json.JSONDecodeError as e:
            print(f"❌ JSON decode error: {e}")
            print(f"❌ Raw message: {repr(message)}")
        except Exception as e:
            print(f"❌ Error processing message: {e}")
            print(f"❌ Raw message: {repr(message)}")
            import traceback
            traceback.print_exc()
    
    async def process_binary_message(self, websocket, message: bytes):
        """Handle binary audio data from Twilio"""
        # This is likely audio data - add to buffer for processing
        self.audio_buffer.extend(message)
        await self.process_audio_buffer(websocket)
    
    async def process_audio_buffer(self, websocket):
        """Process audio buffer through parallel processing chain - no one hogs the stream."""
        if len(self.audio_buffer) < 1600:  # Need at least 200ms at 8kHz
            return
        
        # Copy buffer and clear it for next chunk
        audio_data = bytes(self.audio_buffer)
        self.audio_buffer.clear()
        
        # PARALLEL PROCESSING - each service gets its own copy of the audio
        
        # 1. DTMF Detection (fast, sends signal to IVR)
        if dtmf_detector:
            dtmf_audio_copy = bytes(audio_data)  # Independent copy
            asyncio.create_task(self._process_dtmf_parallel(websocket, dtmf_audio_copy))
        
        # 2. Speech Recognition (slow, sends signal to IVR) 
        if twilio_bridge and self.call_sid:
            speech_audio_copy = bytes(audio_data)  # Independent copy
            asyncio.create_task(self._process_speech_parallel(websocket, speech_audio_copy))
    
    async def _process_dtmf_parallel(self, websocket, audio_data):
        """Process DTMF in parallel - sends signal to IVR when detected."""
        try:
            dtmf_digit = dtmf_detector.detect_from_audio_bytes(audio_data, format='mulaw')
            if dtmf_digit:
                print(f"🔢 DTMF signal detected: {dtmf_digit}")
                # Send DTMF signal to IVR handler
                await self._send_signal_to_ivr('DTMF', {'digit': dtmf_digit}, websocket)
        except Exception as e:
            print(f"❌ DTMF processing error: {e}")
    
    async def _process_speech_parallel(self, websocket, audio_data):
        """Process speech recognition in parallel - sends signal to IVR when detected."""
        try:
            # Create metadata for the audio
            metadata = {
                'type': 'twilio_stream',
                'format': 'mulaw',
                'sample_rate': 8000,
                'channels': 1,
                'call_sid': self.call_sid,
                'stream_sid': self.stream_sid
            }
            
            # Send to transcription bridge - this will eventually send speech signal to IVR
            await twilio_bridge.process_twilio_audio(self.call_sid, audio_data, metadata)
            print(f"📤 Speech processing: {len(audio_data)} bytes to transcription")
            
        except Exception as e:
            print(f"❌ Speech processing error: {e}")
    
    async def start_ivr_session(self, websocket):
        """Start IVR session for this call"""
        if not ivr_service or not self.call_sid:
            return
        
        try:
            # Start IVR session with tournament tracker script
            response = await ivr_service.start_call(self.call_sid, "tournament_tracker", {
                'platform': 'twilio',
                'websocket': websocket
            })
            
            # Send initial IVR response
            if response.action == 'speak':
                await self.send_tts_response(websocket, response.content)
            elif response.action == 'hangup':
                await self.hangup_call(websocket)
                
            print(f"🎛️ IVR session started for call {self.call_sid}")
            
        except Exception as e:
            print(f"❌ Error starting IVR session: {e}")
    
    async def _send_signal_to_ivr(self, signal_type, data, websocket):
        """Send signals to polymorphic IVR service for processing."""
        if not ivr_service or not self.call_sid:
            # Fallback to old handlers if IVR not available
            if signal_type == 'DTMF':
                await self.handle_dtmf_input(websocket, data['digit'])
            elif signal_type == 'SPEECH':
                await self.handle_transcription(websocket, data['text'])
            return
        
        try:
            # Send input to polymorphic IVR
            response = await ivr_service.process_input(
                self.call_sid, 
                signal_type.lower(), 
                data.get('digit') or data.get('text', '')
            )
            
            # Process IVR response
            if response.action == 'speak':
                await self.send_tts_response(websocket, response.content)
            elif response.action == 'hangup':
                await self.send_tts_response(websocket, response.content)
                await asyncio.sleep(2)
                await self.hangup_call(websocket)
            
            print(f"🎛️ IVR processed {signal_type}: '{data}' → '{response.action}'")
            
        except Exception as e:
            print(f"❌ IVR signal processing error: {e}")
    
    async def get_transcription_result(self) -> Optional[str]:
        """Check for transcription results (simplified implementation)."""
        # In a real implementation, this would be event-driven via announcements
        # For now, we'll return None and let the transcription service handle it
        return None
    
    async def handle_dtmf_input(self, websocket, digit: str):
        """Handle DTMF key press input."""
        print(f"🔢 Processing DTMF digit: {digit}")
        
        try:
            if digit == '1':
                # Player rankings
                response = pq("show top 10 players")
                await self.send_tts_response(websocket, response if response else "Top players: West, Zak, and Bear lead the rankings.")
                
            elif digit == '2':
                # Organization attendance rankings  
                response = pq("show top 5 organizations")
                await self.send_tts_response(websocket, response if response else "Top organizations by attendance: West Coast Warzone, Ultimate Fighting Game Tournament.")
                
            elif digit == '0':
                # Help menu
                await self.send_tts_response(websocket, "Press 1 for player rankings, 2 for organization rankings, or just speak your question.")
                
            elif digit == '*':
                # Repeat menu
                await self.send_tts_response(websocket, "this is the backyard tryhards tracker. press or say 1 for player rankings. 2 for organization attendnance rankings.")
                
            elif digit == '#':
                # End call
                await self.send_tts_response(websocket, "Thanks for calling Try Hard Tournament Tracker. Goodbye!")
                await asyncio.sleep(2)
                await self.hangup_call(websocket)
                
            else:
                # Unknown digit
                await self.send_tts_response(websocket, f"You pressed {digit}. Press 1 for players, 2 for organizations, or 0 for help.")
                
        except Exception as e:
            print(f"❌ Error processing DTMF {digit}: {e}")
            await self.send_tts_response(websocket, "Sorry, I had trouble with that selection.")

    async def handle_transcription(self, websocket, text: str):
        """Handle transcription result and generate response."""
        print(f"🎤 Transcribed: {text}")
        
        # Check for hangup keywords
        hangup_keywords = ["goodbye", "bye", "hang up", "end call", "thank you goodbye", "thanks bye"]
        text_lower = text.lower().strip()
        
        if any(keyword in text_lower for keyword in hangup_keywords):
            print("📞 Hangup detected, ending call")
            await self.send_tts_response(websocket, "Goodbye! Thanks for calling Try Hard Tournament Tracker.")
            
            # Send hangup after TTS completes
            await asyncio.sleep(3)  # Wait for TTS to finish
            await self.hangup_call(websocket)
            return
        
        # Query the tournament system
        try:
            response = pq(text)
            if response:
                print(f"🤖 Response: {response[:100]}...")
                await self.send_tts_response(websocket, response)
            else:
                await self.send_tts_response(
                    websocket, 
                    "I didn't understand that. Can you ask about tournaments, players, or rankings?"
                )
        except Exception as e:
            print(f"❌ Error querying system: {e}")
            await self.send_tts_response(
                websocket,
                "Sorry, I had trouble processing that request."
            )
    
    async def send_tts_response(self, websocket, text: str):
        """Convert text to speech via audio mixer and send via Twilio stream."""
        print(f"📤 TTS Response (via mixer): {text[:50]}...")
        
        # Announce text for TTS - the mixer will listen for this
        announcer.announce(
            "TEXT_TO_SPEECH",
            [
                f"TEXT: {text}",
                "VOICE: normal",
                "FORMAT: mulaw_8khz",
                "TARGET: twilio_stream_via_mixer"
            ]
        )
        
        # Send real TTS audio via announcements system
        await self.send_tts_to_mixer(text)
    
    async def _announce_time_via_mixer(self, websocket):
        """Announce current time using the audio mixer system"""
        from datetime import datetime
        
        # Get current time with proper formatting
        now = datetime.now()
        time_str = now.strftime("%I:%M %p")
        time_announcement = f"The time is {time_str}."
        
        print(f"🕒 Announcing via mixer: {time_announcement}")
        
        # Send through mixer system
        await self.send_tts_response(websocket, time_announcement)
        
        # Brief pause, then menu
        await asyncio.sleep(1)
        menu_text = "This is the Backyard Tryhards stat tracker. Press or say 1 for top players, 2 for top organizations by attendance, or 0 for current date and time."
        await self.send_tts_response(websocket, menu_text)

    async def send_tts_to_mixer(self, text: str):
        """Send TTS to audio mixer for proper mixing with background music"""
        print(f"🔊 Sending TTS to mixer for mixing: {text[:50]}...")
        
        try:
            # Use audio mixer's real-time mixing to get actual mixed audio
            if audio_mixer:
                print("🎚️ Using audio mixer for TTS + background music mixing")
                print(f"🎚️ DEBUG: audio_mixer type = {type(audio_mixer)}")
                # Get mixed audio (TTS + background music) from mixer
                print("🎚️ DEBUG: Calling audio_mixer.mix_realtime()...")
                mixed_audio = audio_mixer.mix_realtime(text)
                print(f"🎚️ DEBUG: mix_realtime returned: {type(mixed_audio)} length={len(mixed_audio) if mixed_audio else 'None'}")
                
                if mixed_audio:
                    print(f"🎚️ Received {len(mixed_audio)} bytes of mixed audio from mixer")
                    # Send the mixed audio directly to Twilio
                    await self._send_mixed_audio_to_twilio(mixed_audio)
                else:
                    print("⚠️ Mixer returned no audio, using direct TTS fallback")
                    await self._send_direct_tts(text)
            else:
                print("⚠️ No audio mixer available for TTS mixing")
                # Fallback: send TTS directly (but this won't mix with music)
                await self._send_direct_tts(text)
                
        except Exception as e:
            print(f"🔊 TTS mixer error: {e}")
            import traceback
            traceback.print_exc()
            # Fallback: send TTS directly
            await self._send_direct_tts(text)
    
    async def _send_mixed_audio_to_twilio(self, mixed_audio: bytes):
        """Send pre-mixed audio (TTS + background music) to Twilio"""
        print(f"🎵 Sending {len(mixed_audio)} bytes of mixed audio to Twilio")
        
        try:
            import base64
            
            # Convert to base64 for Twilio WebSocket
            audio_b64 = base64.b64encode(mixed_audio).decode('utf-8')
            
            # Send via WebSocket in chunks
            chunk_size = 4000  # Twilio chunk size
            total_chunks = len(audio_b64) // chunk_size + (1 if len(audio_b64) % chunk_size else 0)
            
            for i in range(0, len(audio_b64), chunk_size):
                chunk = audio_b64[i:i+chunk_size]
                
                media_message = {
                    "event": "media",
                    "media": {
                        "payload": chunk
                    }
                }
                
                if self.current_websocket:
                    await self.current_websocket.send(json.dumps(media_message))
                    print(f"📤 Sent audio chunk {i//chunk_size + 1}/{total_chunks}")
                else:
                    print("❌ ERROR: No websocket available to send audio!")
            
            print(f"🔊 Sent mixed audio in {total_chunks} chunks to Twilio")
            
        except Exception as e:
            print(f"🔊 Error sending mixed audio: {e}")
    
    async def _send_direct_tts(self, text: str):
        """Fallback: send TTS directly to Twilio (bypasses mixer)"""
        print(f"🔊 Fallback: Generating direct TTS audio: {text[:50]}...")
        
        try:
            # Generate TTS audio directly using espeak, convert to mulaw for Twilio
            import subprocess
            import tempfile
            import os
            
            # Step 1: Generate WAV audio with espeak 
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as wav_file:
                wav_path = wav_file.name
            
            # Generate WAV with espeak
            cmd_wav = ['espeak', '-s', '175', '-p', '50', '-g', '2', '-w', wav_path, text]
            result = subprocess.run(cmd_wav, capture_output=True, check=False)
            
            if result.returncode == 0 and os.path.exists(wav_path):
                # Step 2: Convert WAV to mulaw using ffmpeg (what Twilio expects)
                cmd_mulaw = [
                    'ffmpeg', '-y', '-i', wav_path,
                    '-acodec', 'pcm_mulaw', '-ar', '8000', '-ac', '1',
                    '-f', 'mulaw', 'pipe:1'
                ]
                mulaw_result = subprocess.run(cmd_mulaw, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                
                # Clean up WAV file
                os.unlink(wav_path)
                
                if mulaw_result.returncode == 0 and mulaw_result.stdout:
                    print(f"🔊 Generated {len(mulaw_result.stdout)} bytes of mulaw TTS audio")
                    
                    # Convert to base64 for Twilio
                    import base64
                    audio_base64 = base64.b64encode(mulaw_result.stdout).decode('utf-8')
                    
                    # Send TTS audio directly to Twilio
                    if hasattr(self, 'current_websocket'):
                        tts_message = {
                            "event": "media",
                            "streamSid": self.stream_sid,
                            "media": {
                                "payload": audio_base64
                            }
                        }
                        await self.current_websocket.send(json.dumps(tts_message))
                        print(f"🔊 Sent TTS audio directly to Twilio")
                    else:
                        print("⚠️ No websocket connection for TTS")
                else:
                    print(f"🔊 Mulaw conversion failed: {mulaw_result.stderr.decode() if mulaw_result.stderr else 'Unknown error'}")
            else:
                print(f"🔊 WAV generation failed: {result.stderr.decode() if result.stderr else 'Unknown error'}")
                
        except Exception as e:
            print(f"🔊 TTS error: {e}")
    
    async def stream_mixer_to_twilio(self, websocket):
        """Simple direct connection: mixer output → Twilio. That's it."""
        try:
            print("🎚️ Direct mixer-to-Twilio connection starting")
            
            while True:
                # Get audio from mixer
                chunk = audio_mixer.get_music_chunk(160)
                if chunk:
                    # Send to Twilio
                    encoded = base64.b64encode(chunk).decode('utf-8')
                    await websocket.send(json.dumps({
                        "event": "media",
                        "streamSid": self.stream_sid,
                        "media": {"payload": encoded}
                    }))
                
                await asyncio.sleep(0.02)  # 20ms
                
        except Exception as e:
            print(f"🎚️ Mixer connection ended: {e}")
    
    
    async def stream_mixed_audio_to_twilio(self, websocket, mixer, text: str):
        """Stream mixed audio from mixer directly to Twilio."""
        try:
            print(f"🎚️ Streaming mixed audio to Twilio: {text[:30]}...")
            
            # Get continuous mixed audio chunks from mixer
            duration_seconds = max(2, len(text.split()) * 0.3)  # Estimate duration
            total_chunks = int(duration_seconds / 0.02)  # 20ms chunks
            
            for chunk_num in range(total_chunks):
                # Get audio chunk from mixer (this includes background music + TTS)
                audio_chunk = mixer.get_music_chunk(160)  # 160 bytes = 20ms at 8kHz mulaw
                
                if not audio_chunk:
                    break
                
                # Base64 encode for Twilio
                encoded_chunk = base64.b64encode(audio_chunk).decode('utf-8')
                
                # Create media message
                media_message = {
                    "event": "media",
                    "streamSid": self.stream_sid,
                    "media": {
                        "payload": encoded_chunk
                    }
                }
                
                # Send to Twilio
                await websocket.send(json.dumps(media_message))
                
                # 20ms delay between chunks for real-time streaming
                await asyncio.sleep(0.02)
            
            # Send completion mark
            mark_message = {
                "event": "mark",
                "streamSid": self.stream_sid,
                "mark": {
                    "name": "mixed_audio_complete"
                }
            }
            await websocket.send(json.dumps(mark_message))
            
            print(f"🎚️ Completed streaming mixed audio for: {text[:30]}...")
            
        except Exception as e:
            print(f"❌ Error streaming mixed audio: {e}")
            import traceback
            traceback.print_exc()
            # NO FALLBACK - force TTS mixer to work or fail loudly
    
    async def stream_mixer_output(self, websocket):
        """Stream the mixer's combined audio output (music + TTS) to Twilio."""
        try:
            print("🎚️ Starting mixer output stream - this is the main audio sink!")
            
            if not audio_mixer:
                print("⚠️ No audio mixer available")
                return
            
            chunk_count = 0
            # Stream the mixer's combined output
            while True:
                try:
                    # Get mixed audio chunk (music + any TTS in queue)
                    audio_chunk = audio_mixer.get_music_chunk(160)  # This should be the MIXED output
                    
                    if not audio_chunk:
                        print(f"🎚️ Mixer output empty after {chunk_count} chunks, restarting...")
                        audio_mixer.start_continuous_music()
                        await asyncio.sleep(0.1)
                        continue
                    
                    # Base64 encode for Twilio
                    encoded_chunk = base64.b64encode(audio_chunk).decode('utf-8')
                    
                    # Create media message
                    media_message = {
                        "event": "media",
                        "streamSid": self.stream_sid,
                        "media": {
                            "payload": encoded_chunk
                        }
                    }
                    
                    # Send mixed audio to Twilio
                    try:
                        await websocket.send(json.dumps(media_message))
                        chunk_count += 1
                        
                        # Log progress every 5 seconds (250 chunks)
                        if chunk_count % 250 == 0:
                            print(f"🎚️ Mixed audio streaming: {chunk_count} chunks sent")
                            
                    except Exception as send_error:
                        print(f"❌ Websocket send failed: {send_error}")
                        break
                    
                    # 20ms delay for real-time streaming
                    await asyncio.sleep(0.02)
                    
                except Exception as e:
                    print(f"❌ Error in mixer output processing: {e}")
                    await asyncio.sleep(1)
                    
        except asyncio.CancelledError:
            print("🎚️ Mixer output streaming cancelled (call ended)")
        except Exception as e:
            print(f"❌ Fatal error in mixer output streaming: {e}")
        finally:
            print(f"🎚️ Mixer output stream ended after {chunk_count} chunks")
    
    async def stream_background_music_safely(self, websocket):
        """Safely stream background music without hanging up the call."""
        try:
            print("🎵 Starting SAFE background music stream")
            
            if not audio_mixer or not audio_mixer.background_music:
                print("⚠️ No background music available")
                return
            
            chunk_count = 0
            # Stream music but with error handling to prevent hangups
            while True:
                try:
                    # Get music chunk from mixer
                    audio_chunk = audio_mixer.get_music_chunk(160)  # 20ms chunks
                    
                    if not audio_chunk:
                        print(f"🎵 Music chunk empty after {chunk_count} chunks, restarting...")
                        audio_mixer.start_continuous_music()
                        await asyncio.sleep(0.1)
                        continue
                    
                    # Base64 encode for Twilio
                    encoded_chunk = base64.b64encode(audio_chunk).decode('utf-8')
                    
                    # Create media message
                    media_message = {
                        "event": "media",
                        "streamSid": self.stream_sid,
                        "media": {
                            "payload": encoded_chunk
                        }
                    }
                    
                    # Send to Twilio safely
                    try:
                        await websocket.send(json.dumps(media_message))
                        chunk_count += 1
                        
                        # Log progress every 5 seconds (250 chunks)
                        if chunk_count % 250 == 0:
                            print(f"🎵 Music streaming: {chunk_count} chunks sent")
                            
                    except Exception as send_error:
                        print(f"❌ Websocket send failed: {send_error}")
                        break  # Exit music loop if websocket is dead
                    
                    # 20ms delay for real-time streaming
                    await asyncio.sleep(0.02)
                    
                except Exception as e:
                    print(f"❌ Error in music chunk processing: {e}")
                    await asyncio.sleep(1)  # Wait before retrying
                    
        except asyncio.CancelledError:
            print("🎵 Background music streaming cancelled (call ended)")
        except Exception as e:
            print(f"❌ Fatal error in background music streaming: {e}")
        finally:
            print(f"🎵 Background music stream ended after {chunk_count} chunks")
    
    async def stream_background_music_continuously(self, websocket):
        """Continuously stream background music to Twilio - this is the 'play' button!"""
        try:
            print("🎵 Starting continuous background music stream to Twilio")
            
            if not audio_mixer or not audio_mixer.background_music:
                print("⚠️ No background music available")
                return
            
            # Stream background music continuously until call ends
            while True:
                try:
                    # Get music chunk from mixer - this is the actual "play" action
                    audio_chunk = audio_mixer.get_music_chunk(160)  # 20ms chunks
                    
                    if not audio_chunk:
                        print("🎵 Music chunk empty, restarting...")
                        audio_mixer.start_continuous_music()
                        continue
                    
                    # Base64 encode for Twilio
                    encoded_chunk = base64.b64encode(audio_chunk).decode('utf-8')
                    
                    # Create media message
                    media_message = {
                        "event": "media",
                        "streamSid": self.stream_sid,
                        "media": {
                            "payload": encoded_chunk
                        }
                    }
                    
                    # Send to Twilio - this is where caller hears the music!
                    await websocket.send(json.dumps(media_message))
                    
                    # 20ms delay for real-time streaming
                    await asyncio.sleep(0.02)
                    
                except Exception as e:
                    print(f"❌ Error in background music streaming: {e}")
                    await asyncio.sleep(1)  # Wait before retrying
                    
        except asyncio.CancelledError:
            print("🎵 Background music streaming cancelled")
        except Exception as e:
            print(f"❌ Fatal error in background music streaming: {e}")
    
    async def hangup_call(self, websocket):
        """Send hangup command to Twilio to end the call."""
        try:
            # Stop the stream first
            stop_message = {
                "event": "stop",
                "streamSid": self.stream_sid
            }
            await websocket.send(json.dumps(stop_message))
            print("📞 Sent stop message to Twilio")
            
            # Close the websocket connection
            await websocket.close()
            print("📞 WebSocket connection closed")
            
            # Stop background music via announcer
            announcer.announce(
                "STOP_CONTINUOUS_MUSIC",
                [
                    "Call ended, stopping background music",
                    "Mixer should stop streaming",
                    "Audio resources released"
                ]
            )
            
        except Exception as e:
            print(f"❌ Error hanging up call: {e}")


async def main():
    """Start the polymorphic Twilio stream server."""
    handler = TwilioStreamPolymorphic()
    
    port = 8088  # Different port from other stream servers
    
    # Create proper handler function that matches websockets.serve expectations
    def websocket_handler(websocket):
        path = getattr(websocket, 'path', '/') if hasattr(websocket, 'path') else '/'
        return handler.handle_websocket(websocket, path)
    
    # SSL context setup
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    cert_path = pathlib.Path(__file__).parent / "server.crt"
    key_path = pathlib.Path(__file__).parent / "server.key"
    
    if cert_path.exists() and key_path.exists():
        ssl_context.load_cert_chain(cert_path, key_path)
        print(f"🔐 SSL enabled with certificate: {cert_path}")
        ws_url = f"wss://64.111.98.139:{port}/"
    else:
        print("⚠️ SSL certificates not found, running without SSL")
        ssl_context = None
        ws_url = f"ws://64.111.98.139:{port}/"
    
    print(f"🚀 Starting Polymorphic Twilio Stream Server on port {port}")
    print(f"📡 WebSocket URL: {ws_url}")
    print("🔗 Integrated with polymorphic transcription and TTS")
    print("⏳ Waiting for Twilio streams...")
    
    # Start WebSocket server
    async with websockets.serve(
        websocket_handler,
        "0.0.0.0",
        port,
        ssl=ssl_context,
        # Twilio-specific settings
        compression=None,  # Twilio doesn't support compression
        max_size=10 * 1024 * 1024,  # 10MB max message size
        ping_interval=None,  # Twilio handles keepalive
        ping_timeout=None
    ):
        # Keep server running
        await asyncio.Future()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Shutting down polymorphic stream server")